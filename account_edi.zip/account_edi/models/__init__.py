# -*- encoding: utf-8 -*-

from . import account_move
from . import account_journal
from . import account_edi_format
from . import account_edi_document
from . import mail_template
